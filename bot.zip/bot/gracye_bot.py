import discord
from discord.ext import commands
import random
import os

TOKEN = os.getenv("VAR_GRACYE_bot")
if not TOKEN:
    raise RuntimeError("Configure a variável VAR_GRACYE_bot")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"{bot.user} conectado!")
    await bot.tree.sync()

@bot.command()
async def olagracye(ctx):
    await ctx.send("a vizinha do gracye e uma cachorra 🐶")

@bot.command()
async def ping(ctx):
    await ctx.send(f"🏓 {round(bot.latency * 1000)}ms")

@bot.command()
async def sorte(ctx):
    await ctx.send(random.choice(["⭐ Ótima!", "👍 Boa!", "😐 Média", "😢 Ruim"]))

@bot.command()
async def somar(ctx, a: float, b: float):
    await ctx.send(f"{a} + {b} = **{a + b}**")

@bot.command()
async def fala(ctx, *, msg: str):
    await ctx.send(msg)

@bot.command()
async def ajuda(ctx):
    embed = discord.Embed(title="📋 Comandos", color=0x00ff00)
    embed.add_field(name="!olagracye", value="Saudação", inline=False)
    embed.add_field(name="!ping", value="Latência", inline=False)
    embed.add_field(name="!sorte", value="Sorte", inline=False)
    embed.add_field(name="!somar a b", value="Soma", inline=False)
    embed.add_field(name="/ship /freque /util", value="Slash", inline=False)
    await ctx.send(embed=embed)

@bot.command()
async def davy_jones(ctx):
    pasta = os.path.join(os.path.dirname(__file__), "davy")
    if not os.path.exists(pasta):
        return await ctx.send("❌ Pasta `davy` não existe!")
    musicas = [m for m in os.listdir(pasta) if m.endswith(".mp3")]
    if not musicas:
        return await ctx.send("❌ Nenhuma música .mp3 encontrada!")
    musica = random.choice(musicas)
    await ctx.send(f"🎶 **{musica}**", file=discord.File(os.path.join(pasta, musica)))

@bot.tree.command(name="ship", description="Faz um ship aleatório 💕")
async def ship(interaction: discord.Interaction):
    membros = [m for m in interaction.guild.members if not m.bot]
    if len(membros) < 2:
        return await interaction.response.send_message("❌ Poucos membros!")
    a, b = random.sample(membros, 2)
    await interaction.response.send_message(f"💕 **{a.mention} x {b.mention}** 💕")

@bot.tree.command(name="freque", description="Mostra frequência 📊")
async def freque(interaction: discord.Interaction):
    online = len([m for m in interaction.guild.members if m.status == discord.Status.online])
    total = interaction.guild.member_count
    await interaction.response.send_message(f"📊 **{online}/{total}** online")

@bot.tree.command(name="util", description="Utilidades ⚙️")
async def util(interaction: discord.Interaction):
    embed = discord.Embed(title="⚙️ Utilitários", color=0xff0000)
    embed.add_field(name="/ship", value="Ship", inline=True)
    embed.add_field(name="/freque", value="Frequência", inline=True)
    embed.add_field(name="/diverla", value="Diversão", inline=True)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="diverla", description="Diversão 🎉")
async def diverla(interaction: discord.Interaction):
    frases = ["😂 KKKKK", "🤡 Palhaçada", "🎊 Festa!", "😎 Topzera"]
    await interaction.response.send_message(random.choice(frases))

bot.run(TOKEN)